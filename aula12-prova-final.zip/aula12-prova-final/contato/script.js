 function validarContato() {
    if (!selectProjeto || selectProjeto == "Escolha um projeto") {
        alert("algo não está certo")
    }
 } // Falta melhorar validação