function validar() {
    if (document.getElementById("email").value == "admin@admin.com" && document.getElementById("senha").value == "senha") {
        alert("login realizado com sucesso")
    }
}